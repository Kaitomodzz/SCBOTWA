const fs = require('fs')

global.owner = "6281543241190"
global.footer = " _© R-KazXy_F ZcoderX 2024 - 2025_"
global.status = true

global.idch = '120363211868027307@newsletter'

const key = 'kyuurzy'

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
