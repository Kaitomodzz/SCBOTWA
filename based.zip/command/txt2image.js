const { txt2 } = require('../start/lib/scrape/scrape-photoleap')
const axios = require('axios');

module.exports = {
    command: 'txt2image',
    type: ['artificial intelligence'],
    description: '*query*',
    async execute(client, m, args, NReply) {
        const text = args.join(" ")
       if (!text) return m.reply(`Example: txt2image cat`)
     let tahu = await txt2(text)
client.sendMessage(m.chat, {image: {url: tahu.data.url}, caption: `Done`}, {quoted: m});
}
};
