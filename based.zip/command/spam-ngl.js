const { spamngl } = require('../start/lib/scrape/scrape-ngl')

module.exports = {
    command: 'spam-ngl',
    type: ['tools'],
    description: '*kyuurzy1|tes*',
    async execute(client, m, args, NReply) {
        const text = args.join(" ")
        if (!text) return NReply('provide the target and the message to be sent. *Example*: .spam-ngl kyuurzy|woii')
        let peler = text.split("|")[0]
        let laso = text.split("|")[1]
        for (let j = 0; j < 30; j++) {
        await spamngl(peler, laso)
        }
        client.sendMessage(m.chat, {
            text: `successfully spam NGL to ${peler} as many as 30 spam` 
          },{quoted:m}
        )
    }
}