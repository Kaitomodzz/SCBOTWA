module.exports = {
    command: 'brat',
    type: ['artificial intelligence'],
    description: '*query*',
    async execute(client, m, args, NReply) {
        const text = args.join(" ")
  if (!text) {
    return m.reply(`*• Example :* brat *[input text]*`);
  }
  try {
      const res = await axios
        .get(
          `https://api.ryzendesu.vip/api/sticker/brat?text=${encodeURIComponent(text)}`,
          {
            responseType: "arraybuffer",
          },
        )
        .catch((e) => e.response);
    await client.sendImageAsSticker(m.chat, res.data, m, {
      packname: global.packname,
      author: global.author,
    });
  } catch (err) {
    console.error(err);
    m.reply("Sorry, an error occurred while processing the request.");
 }
}
};